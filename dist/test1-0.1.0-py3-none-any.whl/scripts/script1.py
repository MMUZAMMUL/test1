def main():
    print("Running script1 from test1 package.")
