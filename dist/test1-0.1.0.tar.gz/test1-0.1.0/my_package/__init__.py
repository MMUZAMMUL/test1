print("Executing test1/my_package/__init__.py")
