def main():
    print("Running script222from test1 package.")
